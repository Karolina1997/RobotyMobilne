function [tab_kal] = kalman_filter(pomiar_zyro, pomiar_akc, K1_kal, K2_kal, dT, n)
tab_kal = zeros(n,1);              %miejsca na zapis danych


xk = zeros(1,2);                        %estymowany kat, dryft zyroskopu
pk = [0.5 0 0 0.01];                    %macierz kowariancji
K = [K1_kal, K2_kal];                        %wzmocnienia kalmana <- analogiczne do tych komplementarnego
phi = [1 dT 0 1];                      %macierz zmiany stanu
psi = [dT 0];                          %macierz wejsciowa
R = 0.03;                               %szum pomiaru <- wplyw korekcji dryftu zyroskpu przez akcelerometr
Q = [0.002^2 0 0 0];                    %szum procesu <- ukazuje dokladnosc modelu stanowego
H = [1 0];                              %macierz wyjsciowa

for i = 1:n;   
 
    %filtr kalmana do estymowania wychylenia i odchylu
    %zyroskopu;
  
    uk = pomiar_zyro(i);                                    %pomiar zyroskopu
    zk = pomiar_akc(i);                                   %pomiar akcelerometru do korekcji 
    
    %xk1Minus = phi*xk + psi*uk;                         %obliczenie nowego stanu bez wplywu akcelerometru 
    xk1Minus(1) = phi(1)*xk(1) + phi(2)*xk(2) + psi(1)*uk; % pobieranie pomiaru z �yroskopu
    xk1Minus(2) = phi(3)*xk(1) + phi(4)*xk(2) + psi(2)*uk;
    
    %pk1Minus = phi*pk*phi' + Q;                         %obliczenie nowej macierzy kowariancji bez wplywu akcelerometru
    pk1Minus(1) = (phi(1)*pk(1) + phi(2)*pk(3))*phi(1) + (phi(1)*pk(2) + phi(2)*pk(4))*phi(2) + Q(1);
    pk1Minus(2) = (phi(1)*pk(1) + phi(2)*pk(3))*phi(3) + (phi(1)*pk(2) + phi(2)*pk(4))*phi(4) + Q(2);
    pk1Minus(3) = (phi(3)*pk(1) + phi(4)*pk(3))*phi(1) + (phi(3)*pk(2) + phi(4)*pk(4))*phi(2) + Q(3);
    pk1Minus(4) = (phi(3)*pk(1) + phi(4)*pk(3))*phi(3) + (phi(3)*pk(2) + phi(4)*pk(4))*phi(4) + Q(4);
    
    %S = H*pk1Minus*H' + R;                              %wstepne obliczenie macierzy pocniczej S
    S = (H(1)*pk1Minus(1) + H(2)*pk1Minus(3))*H(1) + (H(1)*pk1Minus(2) + H(2)*pk1Minus(4))*H(1) + R; 
    
    %K = pk1Minus*H' + inv(S);                           %obliczenie nowych wzmocnien kalmana
    K(1) = (pk1Minus(1)*H(1) + pk1Minus(2)*H(2))/S;
    K(2) = (pk1Minus(3)*H(1) + pk1Minus(4)*H(2))/S;
    
    %xk1 = xk1Minus + K*(zk - H*xk1Minus);               %wykorzystanie wplywu akcelerometru do obliczenia wlasciwego stanu
    xk1(1) = xk1Minus(1) + K(1)*(zk - (H(1)*xk1Minus(1) + H(2) * xk1Minus(2)));
    xk1(2) = xk1Minus(2) + K(2)*(zk - (H(1)*xk1Minus(1) + H(2) * xk1Minus(2)));
    
    %pk1 = (eye(2,2) - K*H)*pk1Minus;                    %wykorzystanie wplywu akcelerometru do obliczenia wlasciwej macierzy kowariancji
    pk1(1,1) = (1 - K(1)*H(1))*pk1Minus(1) + (0 - K(1)*H(2))*pk1Minus(3);
    pk1(1,2) = (1 - K(1)*H(1))*pk1Minus(2) + (0 - K(1)*H(2))*pk1Minus(4);
    pk1(2,1) = (1 - K(2)*H(1))*pk1Minus(1) + (0 - K(2)*H(2))*pk1Minus(3);
    pk1(2,2) = (1 - K(2)*H(1))*pk1Minus(2) + (0 - K(2)*H(2))*pk1Minus(4);
     
    %zapis danych
    tab_kal(i,:) = xk1(1);
    
    %zapis do nast�pnej p�tli  
    xk = xk1;
    pk = pk1;
end    

        