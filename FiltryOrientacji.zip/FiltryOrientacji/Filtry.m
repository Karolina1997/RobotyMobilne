clc
close all
clear all

% Odczyt danych 
% zerowy wiersz to nag��wek (nazwy kolumn)
% zerowa kolumna to numer pomiaru
pomiar = csvread('navchip.csv', 1, 1); 

dT = 0.01;   % zak�adamy cz�stotliwo�� zbierania danych 100 Hz 
x_gyro = pomiar(:,1); % deg/s
y_gyro = -pomiar(:,2); % deg/s
z_gyro = pomiar(:,3); % deg/s

x_acc = pomiar(:,4); % g
y_acc = -pomiar(:,5); % g
z_acc = pomiar(:,6); % g

% Ca�kowanie pomiaru z �yroskopu do por�wnania
x_i = zeros(length(x_gyro),1);
y_i = zeros(length(y_gyro),1);
z_i = zeros(length(z_gyro),1);
for i=2:length(x_i)
    x_i(i) = x_i(i-1) + x_gyro(i)*dT;
    y_i(i) = y_i(i-1) + y_gyro(i)*dT;
    z_i(i) = z_i(i-1) + z_gyro(i)*dT;
end

% Obliczanie warto�ci odchy�u w stopniach na podstawie
% pomiar�w przyspieszenia z akcelerometru - zamiana jednostek na stopnie
x_acc_ang = zeros(length(x_acc),1);
y_acc_ang = zeros(length(y_acc),1);
z_acc_ang = zeros(length(z_acc),1);
for i=1:length(x_acc_ang)
    x_acc_ang(i) = atan2(y_acc(i), z_acc(i)) * 180 /pi;
    y_acc_ang(i) = atan2(x_acc(i), z_acc(i)) * 180 /pi;
    z_acc_ang(i) = atan2(sqrt(x_acc(i)^2 + y_acc(i)^2), z_acc(i)) * 180/pi;
end

% Przygotowanie parametr�w i wywo�anie funkcji filtruj�cej
n = length(x_acc_ang);

%Parametry filtru komplementarnego
K_kom = 0.1;

%Parametry filtru Kalmana
K1_kal = 0; % (0 ; 1)
K2_kal = 0; % (0 ; 1)

%Parametry filtru Madgwicka
Kp_m = 1;
Ki_m = 1;

% Wywo�anie filtr�w dla pomiar�w osobno dla ka�dej z osi

data_x1 = kalman_filter(x_gyro, x_acc_ang, K1_kal, K2_kal, dT, n);
data_x2 = komp_filter(x_gyro, x_acc_ang, K_kom, dT, n);
data_x3 = ma_filter(x_gyro, x_acc_ang, Kp_m, Ki_m, dT, n);

data_y1 = kalman_filter(y_gyro, y_acc_ang, K1_kal, K2_kal, dT, n);
data_y2 = komp_filter(y_gyro, y_acc_ang, K_kom, dT, n);
data_y3 = ma_filter(y_gyro, y_acc_ang, Kp_m, Ki_m, dT, n);

data_z1 = kalman_filter(z_gyro, z_acc_ang, K1_kal, K2_kal, dT, n);
data_z2 = komp_filter(z_gyro, z_acc_ang, K_kom, dT, n);
data_z3 = ma_filter(z_gyro, z_acc_ang, Kp_m, Ki_m, dT, n);

figure(1);
plot(1:n, x_i);
hold on
plot(1:n, data_x2(:,1));
hold on
plot(1:n, data_x1(:,1));
hold on
plot(1:n, data_x3(:,1));
hold on
title('Wyniki dla osi X')
legend('Sc. pomiar �yroskopu', 'Filtr komplementarny', 'Filtr Kalmana', 'Filtr Madgwicka');
grid on;

figure(2);

plot(1:n, y_i);
hold on
plot(1:n, data_y2(:,1));
hold on
plot(1:n, data_y1(:,1));
hold on
plot(1:n, data_y3(:,1));
title('Wyniki dla osi Y')
legend('Sc. pomiar �yroskopu', 'Filtr komplementarny', 'Filtr Kalmana', 'Filtr Madgwicka');
grid on;

figure(3);

plot(1:n, z_i);
hold on
plot(1:n, data_z2(:,1));
hold on
plot(1:n, data_z1(:,1));
hold on
plot(1:n, data_z3(:,1));
title('Wyniki dla osi Z')
legend('Sc. pomiar �yroskopu', 'Filtr komplementarny', 'Filtr Kalmana', 'Filtr Madgwicka');
grid on;

figure(4);
plot(1:n, x_acc_ang);
hold on
plot(1:n, y_acc_ang);
hold on
plot(1:n, z_acc_ang);
title('Po�o�enie wyznaczone na podstwaie pomiar�w z akcelerometru')
legend('x', 'y', 'z');
grid on;