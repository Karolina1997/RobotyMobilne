function [tab_ma] = ma_filter(pomiar_zyro, pomiar_akc, Kp_m, Ki_m, dT, n)
tab_ma = zeros(n,1);              %miejsca na zapis danych

% parametry filtru Madgwicka
Kp = Kp_m;
Ki = Ki_m;
kat_m = 0.0;
integM = 0.0;

for i = 1:n;
    
    %wykorzystanie filtru Madgwicka
    alfaM = 1 - Kp*dT;
    e = integM + Ki*dT*(pomiar_akc(i) - kat_m);
    kat_m1 = alfaM*kat_m + (1 - alfaM)*pomiar_akc(i) + (pomiar_zyro(i) + e)*dT;
    
    %zapisanie danych
    tab_ma(i,:) = kat_m1;
    
    %przej�cie do nast�pnej p�tli   
    integM = e;    
    kat_m = kat_m1;  
end    

        