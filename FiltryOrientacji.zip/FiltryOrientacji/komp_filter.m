function [tab_kom] = komp_filter(pomiar_zyro, pomiar_akc, K_kom, dT, n)
tab_kom = zeros(n,1);              %miejsca na zapis danych

% parametry filtru komplementarnego
kat_k = 0.0;

gainK2 = K_kom;                          %wzmocnienie korekcji dryftu (przez akcelerometr)
gainK1 = 1 - gainK2;                      %wzmocnienie �yroskopu

for i = 1:n;    
    
    %wykorzystanie filtru komplementarnego do kompensacji dryftu �yroskopu
    kat_k1 = gainK1*(kat_k + pomiar_zyro(i)*dT) + gainK2*pomiar_akc(i);    
    
    %zapisanie interesujacych nas danych
    tab_kom(i,1) = kat_k1;
    
    %zapisanie wartosci do nastepnej petli 
    kat_k = kat_k1; 
end    

        